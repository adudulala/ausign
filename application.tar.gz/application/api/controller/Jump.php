<?php
namespace app\api\controller;
use think\Controller;
use think\Db;

class Jump extends Controller{
	public function index(){
		if (isset($_GET['app_id'])) {
			$app_id = $_GET['app_id'];
			$UDID = input('param.udid');
			// 获取UDID
			$data = file_get_contents('php://input');
			if($data){
				$plistBegin = '<?xml version="1.0"';
				$plistEnd = '</plist>';
				$pos1 = strpos($data, $plistBegin);
				$pos2 = strpos($data, $plistEnd);
				$data2 = substr($data,$pos1,$pos2-$pos1);
				$xml = xml_parser_create();
				xml_parse_into_struct($xml, $data2, $vs);
				xml_parser_free($xml);
				$UDID = "";
				$CHALLENGE = "";
				$DEVICE_NAME = "";
				$DEVICE_PRODUCT = "";
				$DEVICE_VERSION = "";
				$iterator = 0;
				$arrayCleaned = array();
				foreach($vs as $v){
				    if($v['level'] == 3 && $v['type'] == 'complete'){
				    	$arrayCleaned[]= $v;
				    }
					$iterator++;
				}
				$data_1 = "";
				$iterator = 0;
				foreach($arrayCleaned as $elem){
				    $data_1 .= "\n==".$elem['tag']." -> ".$elem['value']."<br/>";
				    switch ($elem['value']) {
				        case "CHALLENGE":
				            $CHALLENGE = $arrayCleaned[$iterator+1]['value'];
				            break;
				        case "DEVICE_NAME":
				            $DEVICE_NAME = $arrayCleaned[$iterator+1]['value'];
				            break;
				        case "PRODUCT":
				            $DEVICE_PRODUCT = $arrayCleaned[$iterator+1]['value'];
				            break;
				        case "UDID":
				            $UDID = $arrayCleaned[$iterator+1]['value'];
				            break;
				        case "VERSION":
				            $DEVICE_NAME = $arrayCleaned[$iterator+1]['value'];
				            break;
				    }
					$iterator++;
				}
			}

			$device = Db::name('spDevice')->where(['udid'=>$UDID,'app_id'=>$app_id])->find();
			$app_item = Db::name('spApp')->where('id',$app_id)->find();
			if ($device) {
				Db::name('spDevice')->where(['udid'=>$UDID,'app_id'=>$app_id])->update(['isok'=>0]);
				$plist = get_downloadurl($device['plist']);
				$name = $app_item['name'];
				$logo = $app_item['logo'];
			}else{
				$device_acc = Db::name('spDeviceAcc')->where('udid',$UDID)->find();
				if ($device_acc) {
					$acc_item = Db::name('spAcc')->where('id',$device_acc['acc_id'])->find();
				}else{
					$acc_item = Db::name('spAcc')->where(['status'=>1])->where('leftover','>',0)->find();
					$data = Db::name('spAcc')->where('leftover',0)->where('status',1)->find();
                    if( $data ){
                        Db::name('spAcc')->where('id',$data['id'])->update(['status'=>0]);
                    }
					Db::name('spAcc')->where('id',$acc_item['id'])->setDec('leftover');
					$device_acc_data['udid'] = $UDID;
					$device_acc_data['acc_id'] = $acc_item['id'];
					Db::name('spDeviceAcc')->insert($device_acc_data);
				}
				if ($acc_item) {
					$device_data['udid'] = $UDID;
					$device_data['ipa'] = $UDID.'-'.$app_id.'.ipa';
					$device_data['plist'] = $UDID.'-'.$app_id.'.plist';
					$device_data['expire'] = $acc_item['expire'];
					$device_data['profile'] = $UDID.'.mobileprovision';
					$device_data['acc_id'] = $acc_item['id'];
					$device_data['app_id'] = $app_item['id'];
					Db::name('spDevice')->insert($device_data);
					$name = $app_item['name'];
					$logo = $app_item['logo'];
					$plist = get_downloadurl($UDID.'-'.$app_id.'.plist');
				}else{
					echo "没有证书";
				}
			}
			return $this->redirect('https://'.$_SERVER['HTTP_HOST'].'/index.html?title='.$name.'&plistURL='.$plist.'&img='.$logo,301);
		}else{
			echo "参数不全";
		}
	}

}