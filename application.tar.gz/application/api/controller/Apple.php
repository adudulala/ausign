<?php
namespace app\api\controller;
use think\Controller;
use think\Db;
use Lcobucci\JWT\Builder;
use Lcobucci\JWT\Signer\Key;
use Lcobucci\JWT\Signer\Ecdsa\Sha256;


class Apple extends Controller
{

    public function get_device(){
    	$data = input('param.');
    	file_put_contents('/www/wwwroot/app.jzyf77.com/static/upload/device.txt', "get_device\n", FILE_APPEND);
    }

	public function jump(){
		$app_id = $_GET['app_id'];
		$UDID = input('param.udid');
		$name = '';
		$plist = '';
		$logo = '';
		$target_path = '/www/wwwroot/app.jzyf77.com/static/target/';
		$ausign_path = '/www/wwwroot/app.jzyf77.com/static/ausign/';
		// 获取UDID
		$data = file_get_contents('php://input');
		if($data){
			$plistBegin = '<?xml version="1.0"';
			$plistEnd = '</plist>';
			$pos1 = strpos($data, $plistBegin);
			$pos2 = strpos($data, $plistEnd);
			$data2 = substr($data,$pos1,$pos2-$pos1);
			$xml = xml_parser_create();
			xml_parse_into_struct($xml, $data2, $vs);
			xml_parser_free($xml);
			$UDID = "";
			$CHALLENGE = "";
			$DEVICE_NAME = "";
			$DEVICE_PRODUCT = "";
			$DEVICE_VERSION = "";
			$iterator = 0;
			$arrayCleaned = array();
			foreach($vs as $v){
			    if($v['level'] == 3 && $v['type'] == 'complete'){
			    	$arrayCleaned[]= $v;
			    }
				$iterator++;
			}
			$data_1 = "";
			$iterator = 0;
			foreach($arrayCleaned as $elem){
			    $data_1 .= "\n==".$elem['tag']." -> ".$elem['value']."<br/>";
			    switch ($elem['value']) {
			        case "CHALLENGE":
			            $CHALLENGE = $arrayCleaned[$iterator+1]['value'];
			            break;
			        case "DEVICE_NAME":
			            $DEVICE_NAME = $arrayCleaned[$iterator+1]['value'];
			            break;
			        case "PRODUCT":
			            $DEVICE_PRODUCT = $arrayCleaned[$iterator+1]['value'];
			            break;
			        case "UDID":
			            $UDID = $arrayCleaned[$iterator+1]['value'];
			            break;
			        case "VERSION":
			            $DEVICE_NAME = $arrayCleaned[$iterator+1]['value'];
			            break;
			    }
				$iterator++;
			}
		}
		
		
		$device = Db::name('spDevice')->where(['udid'=>$UDID,'app_id'=>$app_id])->find();
		$app_item = Db::name('spApp')->where('id',$app_id)->find();
		if ($device) {
			$plist = get_downloadurl($device['plist']);
			$name = $app_item['name'];
			$logo = $app_item['logo'];
		}else{
			// 获取证书及包
			$acc_item = Db::name('spAcc')->where(['app_id'=>$app_id, 'status'=>1])->where('leftover','>',0)->find();
			if ($acc_item) {
				// 文件ID
				// $bundleId_id = $acc_item['bundle_id'];
				// $certificate_id = $acc_item['cert_id'];
				// $p12 = $acc_item['p12'];
				// $p12pw = $acc_item['p12pw'];
				// $ipaName = $app_item['ipa_fullpath'];

				// $randnum = time().rand(100000,999999);
				// // 生成JWT凭据
				// $p8 = file_get_contents($acc_item['p8']);
				// $key = $p8;
				// $signer = new Sha256();
				// $time = time();
				// $token = new Builder();
				// $token->setHeader('typ','JWT');
				// $token->setHeader('kid',$acc_item['key_id']);
				// $token->setHeader('alg','ES256');
				// $token->set('iss',$acc_item['issuser_id']);
				// $token->set('exp',time()+600);
				// $token->set('aud','appstoreconnect-v1');
				// $jwt = (string)$token->getToken($signer, new Key($key));
				
				// // 注册设备UDID
				// exec("curl -g -X POST -H 'Content-Type: application/json' -H 'Authorization: Bearer $jwt' -d '{
				// 	\"data\": {
				// 		\"attributes\": {
				// 				\"name\": \"$randnum\",
				// 				\"udid\": \"$UDID\",
				// 				\"platform\": \"IOS\"
				// 		},
				// 		\"type\": \"devices\"
				// 	}
				// }' https://api.appstoreconnect.apple.com/v1/devices",$result,$errno);
				// var_dump($result);
				// // 获取设备文件id
				// $ch = curl_init();
				// curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
				// curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_2_0);
				// curl_setopt($ch, CURLOPT_URL, "https://api.appstoreconnect.apple.com/v1/devices?filter[udid]=$UDID");
				// curl_setopt($ch, CURLOPT_PORT, 443);
				// curl_setopt($ch, CURLOPT_HTTPHEADER, array("Authorization: Bearer ".$jwt));
				// curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
				// curl_setopt($ch, CURLOPT_TIMEOUT, 30);
				// $result = curl_exec($ch);
				// curl_close($ch);
				// $json = json_decode($result,true);
				// echo $json['data'][0]['id']."\n";
				// $device_id = $json['data'][0]['id'];

				// // 生成设备描述文件
				// exec("curl -H 'Authorization: Bearer $jwt' -H 'Content-type:application/json' -X POST -d '{
				// \"data\": {
				// 	\"attributes\":{
				//   	\"name\":\"$randnum\",
				//   	\"profileType\":\"IOS_APP_ADHOC\"
				// 	},
				// 	\"relationships\":{
				//     	\"bundleId\": {
				//         	\"data\": {
				//             	\"id\":\"$bundleId_id\",
				//             	\"type\":\"bundleIds\"
				//         	}
				//     	},
				//     	\"certificates\": {
				//         	\"data\": [{
				//             	\"id\":\"$certificate_id\",
				//             	\"type\":\"certificates\"
				//         	}]
				//     	},
				//     	\"devices\":{
				//         	\"data\": [{
				//             	\"id\":\"$device_id\",
				//             	\"type\":\"devices\"
				//         	}]
				//     	}
				// 	},
				// 	\"type\":\"profiles\"
				// }
				// }' https://api.appstoreconnect.apple.com/v1/profiles 2>&1",$output,$result);
				// // 下载描述文件
				// $ch = curl_init();
				// curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
				// curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_2_0);
				// curl_setopt($ch, CURLOPT_URL, "https://api.appstoreconnect.apple.com/v1/profiles?filter[profileType]=IOS_APP_ADHOC&filter[name]=$randnum");//query：profile名字和刚创建的一样
				// curl_setopt($ch, CURLOPT_PORT, 443);
				// curl_setopt($ch, CURLOPT_HTTPHEADER, array("Authorization: Bearer ".$jwt));
				// curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
				// curl_setopt($ch, CURLOPT_TIMEOUT, 30);
				// $result = curl_exec($ch);
				// curl_close($ch);
				// $json = json_decode($result,true);
				// file_put_contents($target_path.$UDID.'-'.$app_id.'.mobileprovision', base64_decode($json['data'][0]['attributes']['profileContent']));

				// $profile = $target_path.$UDID.'-'.$app_id.'.mobileprovision';
				// // 签名生成安装包
				// exec($ausign_path.'ausign --email millions899@gmail.com -p keiko1003', $output, $result1);
				// echo "<br/>";
				// echo "账号登录<br/>";
				// echo $ausign_path.'ausign --email millions899@gmail.com -p keiko1003'."<br/>";
				// var_dump($output);

				// exec($ausign_path.'ausign --sign '.$ipaName.' -c '.$p12.' -m '.$profile.' -p '.$p12pw.' -o '.$target_path.$UDID.'-'.$app_id.'.ipa', $output, $result2);
				// echo "<br/>";
				// echo "生成结果<br/>";
				// echo $ausign_path.'ausign --sign '.$ipaName.' -c '.$p12.' -m '.$profile.' -p '.$p12pw.' -o '.$target_path.$UDID.'-'.$app_id.'.ipa'."<br/>";
				// var_dump($output);
				// // 生成plist文件
				// plist_write($target_path.$UDID.'-'.$app_id.'.plist',get_downloadurl($UDID.'-'.$app_id.'.ipa'),$acc_item['bundle'],$app_item['name'],$app_item['logo']);

				$device_data['udid'] = $UDID;
				$device_data['ipa'] = $UDID.'-'.$app_id.'.ipa';
				$device_data['plist'] = $UDID.'-'.$app_id.'.plist';
				$device_data['expire'] = $acc_item['expire'];
				$device_data['profile'] = $UDID.'-'.$app_id.'.mobileprovision';
				$device_data['acc_id'] = $acc_item['id'];
				$device_data['app_id'] = $app_item['id'];
				Db::name('spDevice')->insert($device_data);
				$name = $app_item['name'];
				$logo = $app_item['logo'];
				$plist = get_downloadurl($UDID.'-'.$app_id.'.plist');
			}else{
				echo "没有证书了";
			}
		}
		
		// echo 'https://app.jzyf77.com/index.html?title='.$name.'&plistURL='.$plist.'&img='.$logo;
    	return $this->redirect('https://app.jzyf77.com/index.html?title='.$name.'&plistURL='.$plist.'&img='.$logo,301);
    }


}
