<?php
namespace app\manage\controller;

use controller\BasicAdmin;
use service\DataService;
use think\Db;

class Account extends BasicAdmin{
	public $table = 'spAcc';

	public function index(){
        $this->title = '苹果账号管理';
        list($get, $db) = [$this->request->get(), Db::name($this->table)];
        if ( isset($get['username']) && $get['username'] !== '') {
            $db->where('name', $get['username']);
        }
        return parent::_list($db->order('id desc'));
    }


    public function add()
    {
        return $this->_form($this->table, 'form');
    }

    public function edit()
    {
        return $this->_form($this->table, 'form');
    }

    public function _form_filter(&$data)
    {
        if ($this->request->isPost()) {
            
        } else {

        }
    }

    public function forbid()
    {
        if (DataService::update($this->table)) {
            $this->success("禁用成功！", '');
        }
        $this->error("禁用失败，请稍候再试！");
    }

    public function resume()
    {
        if (DataService::update($this->table)) {
            $this->success("启用成功！", '');
        }
        $this->error("启用失败，请稍候再试！");
    }

    public function clear()
    {
    	$id = input('param.id');
    	if( isset($id) ){
    		Db::name($this->table)->where('id',$id)->delete();
    		Db::name('spDevice')->where('acc_id',$id)->delete();
    		Db::name('spDeviceAcc')->where('acc_id',$id)->delete();
    		$this->success("删除成功！", '');
    	}else{
    	    $this->error("删除失败，请稍候再试！");	
    	}
    }
}