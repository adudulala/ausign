<?php
namespace app\manage\controller;

use controller\BasicAdmin;
use service\DataService;
use think\Db;

class App extends BasicAdmin{
	public $table = 'spApp';

	public function index(){
        $this->title = '应用管理';
        list($get, $db) = [$this->request->get(), Db::name($this->table)];
        return parent::_list($db);
    }


    public function add()
    {
        return $this->_form($this->table, 'form');
    }

    public function edit()
    {
        return $this->_form($this->table, 'form');
    }

    public function _form_filter(&$data)
    {
        if ($this->request->isPost()) {
            
        } else {

        }
    }

    public function forbid()
    {
        if (DataService::update($this->table)) {
            $this->success("禁用成功！", '');
        }
        $this->error("禁用失败，请稍候再试！");
    }

    public function resume()
    {
        if (DataService::update($this->table)) {
            $this->success("启用成功！", '');
        }
        $this->error("启用失败，请稍候再试！");
    }

    public function del()
    {
        if (DataService::update($this->table)) {
            $this->success("删除成功！", '');
        }
        $this->error("删除失败，请稍候再试！");
    }
}