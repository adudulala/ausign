<?php
namespace app\manage\controller;

use controller\BasicAdmin;
use service\DataService;
use think\Db;

class Device extends BasicAdmin{
	public $table = 'spDevice';

	public function index(){
        $this->title = '设备管理';
        list($get, $db) = [$this->request->get(), Db::name($this->table)];
        foreach (['app_id', 'acc_id', 'udid'] as $key) {
            (isset($get[$key]) && $get[$key] !== '') && $db->where($key, "{$get[$key]}");
        }

        $app = Db::name('spApp')->where(['status'=>1])->field('id,name')->select();
        $acc = Db::name('spAcc')->where(['status'=>1])->field('id,name')->select();
        $this->assign('app',$app);
        $this->assign('acc',$acc);
        return parent::_list($db->order('id desc'));
    }


    public function add()
    {
        return $this->_form($this->table, 'form');
    }

    public function edit()
    {
        return $this->_form($this->table, 'form');
    }

    public function _form_filter(&$data)
    {
        if ($this->request->isPost()) {
            
        } else {

        }
    }

    public function forbid()
    {
        if (DataService::update($this->table)) {
            $this->success("禁用成功！", '');
        }
        $this->error("禁用失败，请稍候再试！");
    }

    public function resume()
    {
        if (DataService::update($this->table)) {
            $this->success("启用成功！", '');
        }
        $this->error("启用失败，请稍候再试！");
    }

    public function del()
    {
        if (DataService::update($this->table)) {
            $this->success("删除成功！", '');
        }
        $this->error("删除失败，请稍候再试！");
    }
}